from flask import Flask, request
from flask.ext.mysql import MySQL
import checkIn, datetime

# Open connection to the database using the login credentials of the given username and password parameters

# EB looks for an 'application' callable by default.
app = Flask(__name__)

mysql = MySQL()
app.config['MYSQL_DATABASE_DB'] = 'Roster'
app.config['MYSQL_DATABASE_HOST'] = 'dscs-mysql-instance.ca0mrwstseyb.us-west-1.rds.amazonaws.com'
app.config['MYSQL_DATABASE_USER'] = 'DSCSAdmin'
app.config['MYSQL_DATABASE_PASSWORD'] = 'MwCk2016!'
mysql.init_app(app)


@app.route("/")
def index():
	return app.send_static_file("checkIn.html")

@app.route("/admin", methods=["post"])
def admin():


	if db==False:
		return app.send_static_file("index.html")
	else:
		return app.send_static_file("checkIn.html")
	
@app.route("/checkInPrompt", methods=["post"])
def checkInPrompt():
	member = request.form['member']
	if member == "new":
		return app.send_static_file("newmember.html")
	elif member == "returning":
		return app.send_static_file("returningmember.html")
	elif member == "update":
		return app.send_static_file("updateinformation.html")

@app.route("/newMember", methods=["post"])
def newMember():
	first = request.form['first']
	last = request.form['last']
	uname = request.form['uname']
	email = request.form['email']
	phone = request.form['phone']
	test = checkIn.checkDuplicate (mysql, "username",uname)
	now = datetime.datetime.now()
	date = now.strftime("%Y-%m-%d")
	if test==True:
		return app.send_static_file("newmember.html")
	else:
		checkIn.createNew (mysql, first, last, uname, email, phone, date)
		checkIn.checkIn (mysql, uname, date)
	return app.send_static_file("checkIn.html")

@app.route("/returningMember", methods=["post"])
def returningMember():
	uname = request.form['uname']
	test = checkIn.checkDuplicate (mysql,"username",uname)
	now = datetime.datetime.now()
	date = now.strftime("%Y-%m-%d")
	if test==False:
		return app.send_static_file("returningmember.html")
	else:
		checkIn.checkIn (mysql, uname, date)
	return app.send_static_file("checkIn.html")

@app.route("/updateInformation", methods=["post"])
def updateInformation():
	first = request.form['first']
	last = request.form['last']
	field = request.form['field']
	updatedInfo = request.form['updatedInfo']
	now = datetime.datetime.now()
	date = now.strftime("%Y-%m-%d")
	test = checkIn.checkNameDuplicate (mysql,first,last)
	if test==True:
		checkIn.updateInfo (mysql,first,last,field,updatedInfo)
	else:
		return app.send_static_file("updateinformation.html")
	return app.send_static_file("checkIn.html")

# run the app.
if __name__ == "__main__":
	# Setting debug to True enables debug output. This line should be
	# removed before deploying a production app.
	# app.debug = True
	app.run()